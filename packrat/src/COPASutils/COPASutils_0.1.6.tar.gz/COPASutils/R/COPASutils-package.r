#' COPASutils - Easy reading, processing, and manipulation of COPAS BIOSORT data.
#'
#' @name COPASutils
#' @docType package
NULL
